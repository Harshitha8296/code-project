// Challenges functionality
class ChallengeSystem {
    constructor() {
        this.activeChallenges = [];
        this.completedChallenges = [];
    }

    startChallenge(challengeId, points) {
        console.log(`Starting challenge: ${challengeId} for ${points} points`);
        
        // Show challenge instructions
        this.showChallengeModal(challengeId);
        
        return {
            id: challengeId,
            startedAt: new Date(),
            points: points,
            status: 'active'
        };
    }

    showChallengeModal(challengeId) {
        const challengeData = {
            'plant-tree': {
                title: 'Plant a Tree Challenge',
                instructions: `
                    <h3>How to Complete This Challenge:</h3>
                    <ol>
                        <li>Choose a native tree species suitable for your area</li>
                        <li>Find a suitable planting location</li>
                        <li>Dig a hole twice as wide as the root ball</li>
                        <li>Plant the tree and water it thoroughly</li>
                        <li>Take a photo as proof and upload it</li>
                    </ol>
                    <button onclick="completeChallengeWithProof('plant-tree')" class="btn-primary">
                        I've Completed This Challenge
                    </button>
                `
            },
            'plastic-cleanup': {
                title: 'Plastic Cleanup Challenge',
                instructions: `
                    <h3>How to Complete This Challenge:</h3>
                    <ol>
                        <li>Get gloves and a collection bag</li>
                        <li>Clean up plastic waste in your neighborhood</li>
                        <li>Properly dispose of collected plastic</li>
                        <li>Take before/after photos as proof</li>
                        <li>Upload evidence of your cleanup</li>
                    </ol>
                    <button onclick="completeChallengeWithProof('plastic-cleanup')" class="btn-primary">
                        I've Completed This Challenge
                    </button>
                `
            }
        };

        const challenge = challengeData[challengeId];
        if (challenge) {
            const modal = document.getElementById('lesson-modal');
            const content = document.getElementById('lesson-content');
            
            content.innerHTML = `
                <h2>${challenge.title}</h2>
                ${challenge.instructions}
            `;
            
            modal.style.display = 'block';
        }
    }

    completeChallenge(challengeId, proof = null) {
        console.log(`Completing challenge: ${challengeId}`);
        
        // Add points and update user stats
        if (typeof app !== 'undefined') {
            app.completeChallenge(challengeId, 50); // Default 50 points
        }
        
        this.completedChallenges.push({
            id: challengeId,
            completedAt: new Date(),
            proof: proof
        });
        
        return true;
    }
}

// Global challenge functions
function startChallenge(challengeId, points) {
    if (typeof challengeSystem === 'undefined') {
        window.challengeSystem = new ChallengeSystem();
    }
    challengeSystem.startChallenge(challengeId, points);
}

function completeChallengeWithProof(challengeId) {
    if (typeof challengeSystem !== 'undefined') {
        // In a real app, you would upload proof here
        const proof = {
            type: 'photo',
            timestamp: new Date(),
            description: 'Challenge completed successfully'
        };
        
        challengeSystem.completeChallenge(challengeId, proof);
        
        // Close modal
        document.getElementById('lesson-modal').style.display = 'none';
        
        // Show success message
        if (typeof app !== 'undefined') {
            app.showNotification('Challenge completed successfully!', 'success');
        }
    }
}

// Initialize challenge system
const challengeSystem = new ChallengeSystem();