// Enhanced Main Application JavaScript
class EcoLearnApp {
    constructor() {
        this.currentUser = null;
        this.leaderboardData = [];
        this.init();
    }

    init() {
        this.loadUserData();
        this.setupEventListeners();
        this.updateDashboard();
        this.populateLeaderboard();
        this.initializeAnimations();
        
        // Show dashboard by default
        this.switchSection('dashboard');
    }

    loadUserData() {
        const savedUser = localStorage.getItem('ecolearn_user');
        if (savedUser) {
            this.currentUser = JSON.parse(savedUser);
        } else {
            this.currentUser = {
                name: "Student User",
                school: "Green Valley School",
                region: "North India",
                points: 1250,
                badges: ['first-steps', 'eco-warrior', 'tree-hugger', 'clean-up-crew', 'quiz-master', 'water-saver', 'energy-guardian', 'recycling-pro'],
                challengesCompleted: 12,
                carbonSaved: 45,
                treesPlanted: 3,
                plasticCollected: 2.5,
                waterSaved: 350,
                lessonProgress: {
                    'climate-change': 65,
                    'waste-management': 0,
                    'biodiversity': 100,
                    'sustainable-living': 25
                },
                recentActivities: [
                    {
                        type: 'completed',
                        title: 'Completed "Plastic Cleanup" Challenge',
                        description: 'Collected 2kg of plastic waste • +30 points',
                        time: '2 hours ago'
                    },
                    {
                        type: 'lesson',
                        title: 'Finished Climate Change Module',
                        description: 'Scored 92% on the quiz • +50 points',
                        time: '1 day ago'
                    },
                    {
                        type: 'badge',
                        title: 'Earned "Eco Warrior" Badge',
                        description: 'Completed 10+ environmental challenges',
                        time: '2 days ago'
                    }
                ]
            };
            this.saveUserData();
        }
    }

    setupEventListeners() {
        // Navigation - Fixed event listeners
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const targetSection = e.currentTarget.getAttribute('href').substring(1);
                this.switchSection(targetSection);
                
                // Update active nav item
                document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
                e.currentTarget.classList.add('active');
            });
        });

        // Modal close
        const modal = document.getElementById('lesson-modal');
        const closeBtn = document.querySelector('.close');

        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                modal.style.display = 'none';
            });
        }

        window.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });

        // Leaderboard filters
        const regionFilter = document.getElementById('region-filter');
        const timeFilter = document.getElementById('time-filter');
        
        if (regionFilter) {
            regionFilter.addEventListener('change', () => {
                this.populateLeaderboard();
            });
        }
        
        if (timeFilter) {
            timeFilter.addEventListener('change', () => {
                this.populateLeaderboard();
            });
        }

        // CTA Button
        const ctaButton = document.querySelector('.cta-button');
        if (ctaButton) {
            ctaButton.addEventListener('click', () => {
                this.switchSection('lessons');
            });
        }

        // Action cards
        document.querySelectorAll('.action-card').forEach(card => {
            card.addEventListener('click', (e) => {
                const text = card.querySelector('h4').textContent;
                if (text.includes('Learning')) {
                    this.switchSection('lessons');
                } else if (text.includes('Challenges')) {
                    this.switchSection('challenges');
                } else if (text.includes('Ranking')) {
                    this.switchSection('leaderboard');
                } else if (text.includes('Achievements')) {
                    this.showAchievements();
                }
            });
        });

        // Module cards
        document.querySelectorAll('.module-card').forEach(card => {
            card.addEventListener('click', (e) => {
                if (!e.target.classList.contains('module-action')) {
                    const title = card.querySelector('h3').textContent;
                    if (title.includes('Climate')) {
                        startLesson('climate-change');
                    } else if (title.includes('Waste')) {
                        startLesson('waste-management');
                    } else if (title.includes('Biodiversity')) {
                        startLesson('biodiversity');
                    } else if (title.includes('Sustainable')) {
                        startLesson('sustainable-living');
                    }
                }
            });
        });
    }

    switchSection(sectionId) {
        console.log('Switching to section:', sectionId);
        
        // Hide all sections
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
        });
        
        // Show target section
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
            
            // Update navigation
            document.querySelectorAll('.nav-item').forEach(nav => {
                nav.classList.remove('active');
                if (nav.getAttribute('href') === `#${sectionId}`) {
                    nav.classList.add('active');
                }
            });
            
            // Scroll to top
            window.scrollTo(0, 0);
        } else {
            console.error('Section not found:', sectionId);
        }
    }

    updateDashboard() {
        // Update stats
        const totalPoints = document.getElementById('total-points');
        const badgesCount = document.getElementById('badges-count');
        const challengesCompleted = document.getElementById('challenges-completed');
        const carbonSaved = document.getElementById('carbon-saved');

        if (totalPoints) totalPoints.textContent = this.formatNumber(this.currentUser.points);
        if (badgesCount) badgesCount.textContent = this.currentUser.badges.length;
        if (challengesCompleted) challengesCompleted.textContent = this.currentUser.challengesCompleted;
        if (carbonSaved) carbonSaved.textContent = this.currentUser.carbonSaved;

        // Update recent activities
        this.updateRecentActivities();
    }

    updateRecentActivities() {
        const activityList = document.querySelector('.activity-list');
        if (activityList && this.currentUser.recentActivities) {
            activityList.innerHTML = this.currentUser.recentActivities.map(activity => `
                <div class="activity-item">
                    <div class="activity-icon ${activity.type}">
                        <i class="fas fa-${this.getActivityIcon(activity.type)}"></i>
                    </div>
                    <div class="activity-content">
                        <h4>${activity.title}</h4>
                        <p>${activity.description}</p>
                        <span class="activity-time">${activity.time}</span>
                    </div>
                </div>
            `).join('');
        }
    }

    getActivityIcon(type) {
        const icons = {
            'completed': 'check',
            'lesson': 'book',
            'badge': 'medal'
        };
        return icons[type] || 'circle';
    }

    populateLeaderboard() {
        const regionFilter = document.getElementById('region-filter');
        const timeFilter = document.getElementById('time-filter');
        const tbody = document.getElementById('leaderboard-body');
        
        if (!regionFilter || !timeFilter || !tbody) return;

        const regionValue = regionFilter.value;
        const timeValue = timeFilter.value;
        
        // Sample leaderboard data
        this.leaderboardData = [
            { name: "Green Valley School", region: "North India", points: 1250, students: 45, avatar: "GV" },
            { name: "Eco Warriors Academy", region: "South India", points: 1100, students: 38, avatar: "EW" },
            { name: "Sustainable Future School", region: "West India", points: 980, students: 42, avatar: "SF" },
            { name: "Nature Guardians", region: "East India", points: 870, students: 35, avatar: "NG" },
            { name: "Climate Champions", region: "North India", points: 750, students: 28, avatar: "CC" },
            { name: "Earth Savers International", region: "South India", points: 680, students: 31, avatar: "ES" },
            { name: "Green Minds College", region: "West India", points: 550, students: 25, avatar: "GM" }
        ];

        tbody.innerHTML = '';

        const filteredSchools = regionValue === 'all' 
            ? this.leaderboardData 
            : this.leaderboardData.filter(school => 
                school.region.toLowerCase().includes(regionValue));

        filteredSchools.sort((a, b) => b.points - a.points);

        filteredSchools.forEach((school, index) => {
            const row = document.createElement('div');
            row.className = 'leaderboard-item';
            row.innerHTML = `
                <div class="rank rank-${index + 1}">${index + 1}</div>
                <div class="school-info">
                    <div class="school-avatar">${school.avatar}</div>
                    <div class="school-name">${school.name}</div>
                </div>
                <div class="region">${school.region}</div>
                <div class="points">${this.formatNumber(school.points)}</div>
                <div class="students">${school.students}</div>
            `;
            tbody.appendChild(row);
        });
    }

    formatNumber(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    initializeAnimations() {
        // Add intersection observer for scroll animations
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        });

        // Observe all cards for animation
        document.querySelectorAll('.stat-card, .action-card, .module-card, .challenge-card').forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(card);
        });
    }

    addPoints(points) {
        this.currentUser.points += points;
        this.saveUserData();
        this.updateDashboard();
        
        this.showNotification(`+${points} Eco Points!`, 'success');
    }

    completeChallenge(challengeId, points) {
        this.currentUser.challengesCompleted++;
        this.addPoints(points);
        
        // Update specific challenge metrics
        switch(challengeId) {
            case 'plant-tree':
                this.currentUser.treesPlanted++;
                this.currentUser.carbonSaved += 22;
                break;
            case 'plastic-cleanup':
                this.currentUser.plasticCollected += 1;
                this.currentUser.carbonSaved += 3;
                break;
            case 'water-conservation':
                this.currentUser.waterSaved += 100;
                this.currentUser.carbonSaved += 1;
                break;
        }

        // Add to recent activities
        this.currentUser.recentActivities.unshift({
            type: 'completed',
            title: `Completed "${this.getChallengeName(challengeId)}" Challenge`,
            description: `Earned ${points} points`,
            time: 'Just now'
        });

        // Keep only last 5 activities
        this.currentUser.recentActivities = this.currentUser.recentActivities.slice(0, 5);

        this.checkForBadges();
        this.saveUserData();
        this.updateDashboard();
    }

    getChallengeName(challengeId) {
        const names = {
            'plant-tree': 'Plant a Tree',
            'plastic-cleanup': 'Plastic Cleanup',
            'water-conservation': 'Water Conservation',
            'energy-audit': 'Energy Audit'
        };
        return names[challengeId] || challengeId;
    }

    checkForBadges() {
        const newBadges = [];
        
        if (this.currentUser.challengesCompleted >= 1 && !this.currentUser.badges.includes('first-steps')) {
            newBadges.push('first-steps');
        }
        
        if (this.currentUser.challengesCompleted >= 5 && !this.currentUser.badges.includes('eco-warrior')) {
            newBadges.push('eco-warrior');
        }

        if (newBadges.length > 0) {
            this.currentUser.badges.push(...newBadges);
            this.showNotification(`New badge earned: ${newBadges.map(b => this.getBadgeName(b)).join(', ')}!`, 'success');
        }
    }

    getBadgeName(badgeId) {
        const badgeNames = {
            'first-steps': 'First Steps',
            'eco-warrior': 'Eco Warrior',
            'tree-hugger': 'Tree Hugger',
            'clean-up-crew': 'Clean Up Crew'
        };
        return badgeNames[badgeId] || badgeId;
    }

    showNotification(message, type) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 90px;
            right: 24px;
            background: ${type === 'success' ? '#10B981' : '#EF4444'};
            color: white;
            padding: 16px 24px;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.15);
            z-index: 3000;
            animation: slideInRight 0.3s ease;
            font-weight: 600;
            font-size: 1rem;
        `;

        document.body.appendChild(notification);

        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    }

    saveUserData() {
        localStorage.setItem('ecolearn_user', JSON.stringify(this.currentUser));
    }

    showAchievements() {
        this.showNotification('🎉 Achievements feature coming soon!', 'success');
    }
}

// Global functions
function showSection(sectionId) {
    if (window.app) {
        app.switchSection(sectionId);
    }
}

function startLesson(lessonId) {
    const modal = document.getElementById('lesson-modal');
    const content = document.getElementById('lesson-content');
    const title = document.getElementById('modal-title');
    
    const lessons = {
        'climate-change': {
            title: 'Climate Change Fundamentals',
            content: `
                <div class="lesson-content">
                    <div class="lesson-hero">
                        <h3>Understanding Our Changing Climate</h3>
                        <p>Explore the science behind climate change and its global impacts</p>
                    </div>
                    
                    <div class="lesson-section">
                        <h4>🌡️ What is Climate Change?</h4>
                        <p>Climate change refers to long-term shifts in temperatures and weather patterns. These shifts may be natural, but since the 1800s, human activities have been the main driver of climate change.</p>
                    </div>
                    
                    <div class="lesson-section">
                        <h4>🔥 The Greenhouse Effect</h4>
                        <p>Earth's atmosphere acts like a greenhouse, trapping heat from the sun. Human activities are increasing the concentration of greenhouse gases, enhancing this effect and warming the planet.</p>
                    </div>
                    
                    <div class="lesson-section">
                        <h4>📊 Key Statistics</h4>
                        <ul>
                            <li>Global temperature has risen by 1.1°C since pre-industrial times</li>
                            <li>Sea levels are rising 3.6mm per year</li>
                            <li>Arctic sea ice is decreasing by 13% per decade</li>
                        </ul>
                    </div>
                    
                    <div class="lesson-actions">
                        <button class="btn-primary large" onclick="completeLesson('climate-change')">
                            Complete Lesson & Take Quiz
                            <i class="fas fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            `
        },
        'waste-management': {
            title: 'Waste Management & Recycling',
            content: `
                <div class="lesson-content">
                    <div class="lesson-hero">
                        <h3>Mastering the 3 R's</h3>
                        <p>Learn how to reduce, reuse, and recycle for a sustainable future</p>
                    </div>
                    
                    <div class="lesson-section">
                        <h4>♻️ The Waste Hierarchy</h4>
                        <p>Follow this order of priority for sustainable waste management:</p>
                        <ol>
                            <li><strong>Reduce:</strong> Use less stuff - the most effective method</li>
                            <li><strong>Reuse:</strong> Find new uses for items instead of discarding</li>
                            <li><strong>Recycle:</strong> Process materials into new products</li>
                        </ol>
                    </div>
                    
                    <button class="btn-primary large" onclick="completeLesson('waste-management')">
                        Start Learning
                        <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            `
        },
        'biodiversity': {
            title: 'Biodiversity & Ecosystems',
            content: `
                <div class="lesson-content">
                    <div class="lesson-hero">
                        <h3>Exploring Life on Earth</h3>
                        <p>Discover the incredible diversity of species and ecosystems</p>
                    </div>
                    
                    <div class="lesson-section">
                        <h4>🌿 What is Biodiversity?</h4>
                        <p>Biodiversity refers to the variety of life on Earth at all its levels, from genes to ecosystems, and the ecological and evolutionary processes that sustain it.</p>
                    </div>
                    
                    <button class="btn-primary large" onclick="completeLesson('biodiversity')">
                        Start Learning
                        <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            `
        },
        'sustainable-living': {
            title: 'Sustainable Living Practices',
            content: `
                <div class="lesson-content">
                    <div class="lesson-hero">
                        <h3>Living Lightly on Earth</h3>
                        <p>Adopt eco-friendly habits for your daily life</p>
                    </div>
                    
                    <div class="lesson-section">
                        <h4>🏠 Sustainable Home Practices</h4>
                        <p>Learn how to make your home more environmentally friendly through energy efficiency, water conservation, and waste reduction.</p>
                    </div>
                    
                    <button class="btn-primary large" onclick="completeLesson('sustainable-living')">
                        Continue Learning
                        <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            `
        }
    };

    const lesson = lessons[lessonId];
    if (lesson) {
        title.textContent = lesson.title;
        content.innerHTML = lesson.content;
        modal.style.display = 'block';
    }
}

function completeLesson(lessonId) {
    if (window.app && app.currentUser.lessonProgress[lessonId] < 100) {
        app.currentUser.lessonProgress[lessonId] = 100;
        app.addPoints(50);
        app.saveUserData();
        app.showNotification('🎉 Lesson completed! +50 points', 'success');
        
        // Close modal
        document.getElementById('lesson-modal').style.display = 'none';
        
        // Refresh the lessons section to show updated progress
        if (document.getElementById('lessons').classList.contains('active')) {
            app.switchSection('lessons');
        }
    }
}

function startChallenge(challengeId, points) {
    if (window.app) {
        app.completeChallenge(challengeId, points);
        app.showNotification(`🏆 Challenge started! Complete it to earn ${points} points.`, 'success');
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.app = new EcoLearnApp();
});

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);